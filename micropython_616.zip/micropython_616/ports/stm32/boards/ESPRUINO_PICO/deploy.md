For programming an Espruino Pico see the "Advanced Reflashing" section of [this page](http://www.espruino.com/Pico).
