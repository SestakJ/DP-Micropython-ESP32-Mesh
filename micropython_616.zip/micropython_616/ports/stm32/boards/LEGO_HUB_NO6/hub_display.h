void hub_display_on(void);
void hub_display_off(void);
void hub_display_update(void);
void hub_display_set(uint8_t led, uint16_t value);
