freeze(
    ".",
    "neopixel.py",
    opt=3,
)
