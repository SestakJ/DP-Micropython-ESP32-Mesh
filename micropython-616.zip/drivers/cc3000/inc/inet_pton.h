#ifndef __INET_PTON_H
#define __INET_PTON_H
int inet_pton(int, const char *, void *);
#endif /* __INET_PTON_H */
